function result = div(x,y)
	% Integer division
	result = floor(x/y);
end