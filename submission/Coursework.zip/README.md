Computational Neurodynamics Coursework: Dynamical Complexity
============================================================

1.	a)		Plot is 'plots/connectivity.fig'
			Entry point for matlab code: 'p1a.m'

	b,c)	Plots are 	'plots/firing0-0.fig'
						'plots/firing0-1.fig'
						'plots/firing0-2.fig'
						'plots/firing0-3.fig'
						'plots/firing0-4.fig'
						'plots/firing0-5.fig'

			Entry point for matlab code: 'p1bc.m'


2.	Plot is 'plots/neuralcomplexity.fig'

	Matlab code to run an individual simulation for 60 seconds is p2simulation.m

	p2simulation.sh will run multiple trials in parallel

	p2complexity.m reads the data obtained by p2simulation and plots the neural complexity